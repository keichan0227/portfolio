/*
    プログラム名：課題73(typing.c)
    作成者：平塚圭
    作成日：2021/09/16
    概要  ：タイピング
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

/*マクロ定義*/
#define LENGTH 12           // 入力される文字列の長さ
#define MAX_KEYWORD 32      // 問題数
#define MAX_QUESTION 10     // 出題数
#define UNUSED 0            // 未出題
#define USED 1              // 出題済み

/*関数プロトタイプ宣言*/
void init_status(int *p);           // 出題テーブルの初期化
int create_question(int p[]);   	// 問題を選定
int check(char *x, char *y);		// 正誤判定

/*main関数*/
int main(void)
{
    /*出題候補をポインタで定義*/
    char *keyword[] = {"auto","break","case","char","const",
                    "continue","default","do","float","for",
                    "double","eles","enum","extere",
                    "goto","if","int","long","register",
                    "return","short","signed","sizeof","static",
                    "struct","switch","typedef","union","unsigned",
                    "void","volatile","while"};
    char input[LENGTH];                 //解答用
    int status[MAX_KEYWORD];            //出題管理（0：未　1：済）
    int no;                             //問題番号
    int index;                          //出題格納場所
    int error_count = 0;                //入力ミス回数 

    //初期処理
    srand((unsigned)time(NULL));
    init_status(status);            //出題管理を初期化

    //タイトル表示
    printf("＊＊＊　C言語タイピング練習プログラム　＊＊＊\n");
    printf("画面に表示された文字列をキーボードから入力してください。\n\n");

    //主問題
    for(no=1; no <= MAX_QUESTION; no++){
        index = create_question(status);    //問題生成

        //正解するまで繰り返し（無限）
        do{
            printf("[問%d]　%s\n    >>",no,keyword[index]);
            gets(input);    //解答入力
            
            //文字数チェック
            if(strlen(input) != strlen(keyword[index])){
                puts("★入力文字数が違っています。★");
                error_count++;
                continue;
            }

            //文字ミスチェック
             if(check(input,keyword[index])){
                puts("入力をやり直してください。");
                error_count++;
                continue;
            }           
            break;      //次問題へ脱出
        }while(1);      //無限ループ
    }
    printf("＊＊＊　再入力回数 ＝ %d回\n",error_count);
    return 0;
}


/*
    関数名：init_status()
    引　数：出題管理の先頭ポインタ
    戻り値：なし
    概　要：出題管理の初期化
*/
void init_status(int *p)
{
int i;
for(i=0; i<MAX_KEYWORD; i++,p++){
    *p = UNUSED;
}
}

/*
    関数名：create_question()
    引　数：出題管理の先頭ポインタ
    戻り値：出題する予約語のインデックス
    概　要：乱数を基に出題管理で未使用の場所を選びそのインデックスを返す。
           また、出題済みとして出題管理を更新
*/
int create_question(int p[])
{
    int index;
    do{ 
        index = rand()%MAX_KEYWORD;
    }while(p[index] == USED);
    p[index]= USED;
    return index;
}

/*
    関数名：check()
    引　数：文字列1ポインタ、文字列2ポインタ
    戻り値：0   ：二つの値が完全一致した
           0以外：先頭から異なった文字の位置
    概　要：引数２つの文字列を一文字ずつ比較。
    　　　  異なる文字を見つけたら、エラーメッセージ表示してその位置を返す。
        　  2つの文字列を比較しすべての文字が一致したら「0」を返す。
*/
int check(char *x, char *y)
{
    int num=1;
    while(*x){
        if(*x!=*y){
            printf("★%d文字目の文字「%c」は文字「%c」です★\n",num,*x,*y);
            return num;
        }
        num++;
        x++;
        y++;
    }
    return 0;

}


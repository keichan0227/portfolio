/*
    プログラム名：課題82(ABC.c)
    作成者：平塚圭
    作成日：2021/10/06
    概要  ：売上管理（ABC分析）
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>

/*マクロ定義*/
#define MAX_RECORD 10               // 最大レコード数
enum rank {RANK_A=80, RANK_B=95};   // 評価

/*構造体定義*/
typedef struct sales 
{
    char name[20];  // 商品名
    int suryo;      // 数量
    int tanka;      // 単価
    int uriage;     // 売上高
    int total;      // 売上高累計
    double ratio;   // 構成比
    char rank;      // ランク
}SELES;

/*グローバル変数宣言*/
int uriage_total;       //売上高合計(全部の合計)

/*関数のプロトタイプ宣言*/
int input_sales(SELES *deta);               // 売上データの入力とセット
void sort_sales(SELES *deta,int count);     // 売り上げデータのソート
void disp_report(SELES *deta,int count);    // 分析レポートの表示
char get_rank(double rank);                 // 評価の計算

/*main関数*/
int main(void)
{
    SELES detas[MAX_RECORD];
    int count;
    count = input_sales(detas);



    if(count > 0){
    sort_sales(detas,count);
    disp_report(detas,count);
    }

   // コンソールが閉じないようにする処理
    printf("\n終了するにはEnterキーを押してください ");
    while(1){
    	if('\r' == getch()) return 0;
    }

    return 0;
}

/*
    関数名：input_sales()
    引　数：売上データのポインタ
    戻り値：入力件数（整数型）
*/
int input_sales(SELES *deta)
{
    int count=0;
    int ret;

    while(count < MAX_RECORD){
        printf("商品(終了:Ctrl+Z)＞");
        fflush(stdin);
        ret=scanf("%s",deta->name);

        if(ret == EOF){
            break;
        }

        printf("数量＞");
        fflush(stdin);
        ret=scanf("%d",&deta->suryo);

        if(ret <= 0||ret != 1){
            puts("年間販売数は0以上を入力してください。");
            continue;
        }

        printf("単価＞");
        fflush(stdin);
        ret=scanf("%d",&deta->tanka);

        if(ret <= 0||ret != 1){
            puts("単価は0以上を入力してください。");
            continue;
        }

        deta->uriage = deta->suryo * deta->tanka;
        uriage_total += deta->uriage;
        count++;

        deta++;
    }

    return count;
}

/*
    関数名：sort_sales()
    引　数：売上データのポインタ、入力件数（整数型）
    戻り値：なし
*/
void sort_sales(SELES *deta,int count)
{
    int i,j;
    for(i=0; i < count; i++){
        for(j=count-1; j>=i; j--){
            if(deta[j].uriage >= deta[j-1].uriage){
               SELES w = deta[j-1];
                deta[j-1] = deta[j];
                deta[j]= w;
            }
        }
    }
}

/*
    関数名：disp_report()
    引　数：売上データのポインタ、入力件数（整数型）
    戻り値：なし
*/
void disp_report(SELES *deta,int count)
{
    int i;
    static int sum=0;

    puts("          ***  売　上　分　析　表  ***");
    puts("+------------------------------+-----+----+--------+----------+-------+------+");
    puts("|      　商　品　名　         |数量｜単価｜ 売上高 | 売上高累計| 構成比| ランク|");
    puts("+------------------------------+-----+----+--------+----------+-------+------+");
    for(i=0; i<count; i++){
        sum += deta->uriage;
        deta->total = sum;
        deta->ratio = deta->total*100/(double)uriage_total;
        deta->rank = get_rank(deta->ratio);
    printf("|%-30s|%4d｜%4d｜%8d|%10d|%6.1f|  %c  |\n", deta->name, deta->suryo, deta->tanka, deta->uriage, deta->total, deta->ratio, deta->rank);
    deta++;
    }
    puts("+------------------------------+-----+----+--------+----------+-------+------+");
    printf("|                              |   合計  ｜%8d|\n", sum);
    puts("+------------------------------+-----+----+--------+");
}

/*
    関数名：get_rank()
    引　数：構成比（実数型）
    戻り値：ランク（文字型）
*/
char get_rank(double rank)
{
    if(rank >= 0 && rank <= RANK_A){
        return 'A';
    }else if(rank >= RANK_A+1 && rank <= RANK_B){
        return 'B';
    }else{
        return 'C';
    }
}

/*
C:\cwork>kadai82
商品(終了:Ctrl+Z)＞商品1
数量＞110
単価＞2
商品(終了:Ctrl+Z)＞商品2
数量＞60
単価＞40
商品(終了:Ctrl+Z)＞商品3
数量＞10
単価＞4
商品(終了:Ctrl+Z)＞商品4
数量＞130
単価＞1
商品(終了:Ctrl+Z)＞商品5
数量＞50
単価＞12
商品(終了:Ctrl+Z)＞商品6
数量＞1
単価＞25
商品(終了:Ctrl+Z)＞商品7
数量＞10
単価＞2
商品(終了:Ctrl+Z)＞商品8
数量＞150
単価＞2
商品(終了:Ctrl+Z)＞商品9
数量＞20
単価＞2商品10
商品(終了:Ctrl+Z)＞商品10
数量＞年間販売数は0以上を入力してください。
商品(終了:Ctrl+Z)＞^C
C:\cwork>
C:\cwork>kadai82
商品(終了:Ctrl+Z)＞商品1
数量＞110
単価＞2
商品(終了:Ctrl+Z)＞商品2
数量＞60
単価＞40
商品(終了:Ctrl+Z)＞商品3
数量＞10
単価＞4
商品(終了:Ctrl+Z)＞商品4
数量＞130
単価＞1
商品(終了:Ctrl+Z)＞商品5
数量＞50
単価＞12
商品(終了:Ctrl+Z)＞商品6
数量＞1
単価＞25
商品(終了:Ctrl+Z)＞商品7
数量＞10
単価＞2
商品(終了:Ctrl+Z)＞商品8
数量＞150
単価＞2
商品(終了:Ctrl+Z)＞商品9
数量＞20
単価＞2
商品(終了:Ctrl+Z)＞商品10
数量＞50
単価＞1
          ***  売　上　分　析　表  ***
+------------------------------+-----+----+--------+----------+-------+------+
|      　商　品　名　         |数量｜単価｜ 売上高 | 売上高累計| 構成比| ランク|
+------------------------------+-----+----+--------+----------+-------+------+
|商品2                         |  60｜  40｜    2400|      2400|  62.7|  A  |
|商品5                         |  50｜  12｜     600|      3000|  78.4|  A  |
|商品8                         | 150｜   2｜     300|      3300|  86.3|  B  |
|商品1                         | 110｜   2｜     220|      3520|  92.0|  B  |
|商品4                         | 130｜   1｜     130|      3650|  95.4|  C  |
|商品10                        |  50｜   1｜      50|      3700|  96.7|  C  |
|商品3                         |  10｜   4｜      40|      3740|  97.8|  C  |
|商品9                         |  20｜   2｜      40|      3780|  98.8|  C  |
|商品6                         |   1｜  25｜      25|      3805|  99.5|  C  |
|商品7                         |  10｜   2｜      20|      3825| 100.0|  C  |
+------------------------------+-----+----+--------+----------+-------+------+
|                              |   合計  ｜    3825|
+------------------------------+-----+----+--------+

*/